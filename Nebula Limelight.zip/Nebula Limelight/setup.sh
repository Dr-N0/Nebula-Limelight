#!/bin/bash
chmod +x ll_aircrack-ng
mv ~/Desktop/NebulaLL/ll_aircrack-ng /usr/bin

chmod +x ll_apktool
mv ~/Desktop/NebulaLL/ll_apktool /usr/bin

chmod +x ll_armitage
mv ~/Desktop/NebulaLL/ll_armitage /usr/bin

chmod +x ll_autopsy
mv ~/Desktop/NebulaLL/ll_autopsy /usr/bin

chmod +x ll_beef
mv ~/Desktop/NebulaLL/ll_beef /usr/bin

chmod +x ll_commix
mv ~/Desktop/NebulaLL/ll_commix /usr/bin

chmod +x ll_cowpatty
mv ~/Desktop/NebulaLL/ll_cowpatty /usr/bin

chmod +x ll_crunch
mv ~/Desktop/NebulaLL/ll_crunch /usr/bin

chmod +x ll_dmitry
mv ~/Desktop/NebulaLL/ll_dmitry /usr/bin

chmod +x ll_ettercap
mv ~/Desktop/NebulaLL/ll_ettercap /usr/bin

chmod +x ll_fern-wifi-cracker
mv ~/Desktop/NebulaLL/ll_fern-wifi-cracker /usr/bin

chmod +x ll_hashcat
mv ~/Desktop/NebulaLL/ll_hashcat /usr/bin

chmod +x ll_httrack
mv ~/Desktop/NebulaLL/ll_httrack /usr/bin

chmod +x ll_john the ripper
mv ~/Desktop/NebulaLL/ll_john the ripper /usr/bin

chmod +x ll_macchanger
mv ~/Desktop/NebulaLL/ll_macchanger /usr/bin

chmod +x ll_medusa
mv ~/Desktop/NebulaLL/ll_medusa /usr/bin

chmod +x ll_mettasploit
mv ~/Desktop/NebulaLL/ll_mettasploit /usr/bin

chmod +x ll_ncrack
mv ~/Desktop/NebulaLL/ll_ncrack/usr/bin

chmod +x ll_netdiscover
mv ~/Desktop/NebulaLL/ll_netdiscover /usr/bin

chmod +x ll_nmap
mv ~/Desktop/NebulaLL/ll_nmap /usr/bin

chmod +x ll_reaver
mv ~/Desktop/NebulaLL/ll_reaver /usr/bin

chmod +x ll_recon-ng
mv ~/Desktop/NebulaLL/ll_recon-ng /usr/bin

chmod +x ll_setoolkit
mv ~/Desktop/NebulaLL/ll_setoolkit /usr/bin

chmod +x ll_sparta
mv ~/Desktop/NebulaLL/ll_sparta /usr/bin

chmod +x ll_sqlmap
mv ~/Desktop/NebulaLL/ll_sqlmap /usr/bin

chmod +x ll_sqlninja
mv ~/Desktop/NebulaLL/ll_sqlninja /usr/bin

chmod +x ll_termineter
mv ~/Desktop/NebulaLL/ll_termineter /usr/bin

RED='\033[0;31m'
NC='\033[0m'

echo "Thank you for installing Limelight, by Nebula."

echo -e "To run an application, simply run ll_(application name) for more tools and applications visit ${RED}http://nebula.nyc${NC}"

