To setup this module all you have to do is move your folder to your desktop and run these commands.


chmod +x setup.sh

./setup.sh

Just like that, your done!
Now, just read the end text of the setup to learn how to use this application.